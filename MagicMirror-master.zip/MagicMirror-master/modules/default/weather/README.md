# Weather Module

This module aims to be the replacement for the current `currentweather` and `weatherforcast` modules. The module will be configurable to be used as a current weather view, or to show the forecast. This way the module can be used twice to fulfill both purposes.

For configuration options, please check the [MagicMirror² documentation](https://docs.magicmirror.builders/modules/weather.html).
